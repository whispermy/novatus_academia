import numpy as np

# get first input
a = input("Enter the matrix: ").split()
for i in range(0,int(a[0])):
    a.append(input().split())

# str -> int
for i in range(2, len(a)):
    for j in range(0,len(a[i])):
       a[i][j] = int(a[i][j])

# get second input
b = input("Enter the matrix: ").split()
for i in range(0,int(b[0])):
    b.append(input().split())
    
# str -> int
for i in range(2, len(b)):
    for j in range(0,len(b[i])):
           b[i][j] = int(b[i][j])

# get third input
c = input("Enter the matrix: ").split()
for i in range(0,int(c[0])):
    c.append(input().split())

# str -> int
for i in range(2, len(c)):
    for j in range(0,len(c[i])):
           c[i][j] = int(c[i][j])

# make matrix
A_matrix = np.array(a[2:])
B_matrix = np.array(b[2:])
C_matrix = np.array(c[2:])

# A+B
print(A_matrix + B_matrix)

# A-B
print(A_matrix - B_matrix)

# A*B 
print(A_matrix * B_matrix)

# A@C
print(A_matrix @ C_matrix)

# A.transpose
print(np.transpose(A_matrix))

# A중 2보다 큰 갯수
print(np.count_nonzero(A_matrix > 2))

# A 요소합 + B 요소합
print(np.sum(A_matrix) + np.sum(B_matrix))

# B * 10
print(B_matrix*10)

# A 각 요소 세제곱
print(A_matrix * A_matrix * A_matrix)

# A 요소 실수형 형변환
A_matrix = A_matrix.astype('float')
print(A_matrix)







