def quadratic(a, b, c):
    k = b*b - 4*a*c

    if k > 0:
        print((k**0.5 - b)/(2*a),"and",(-k**0.5 - b)/(2*a))
    elif k == 0:
        print((k**0.5 - b)/(2*a))
    else:
        print("No root")


a = float(input("Enter a: "))
b = float(input("Enter b: "))
c = float(input("Enter c: "))

quadratic(a, b, c)

