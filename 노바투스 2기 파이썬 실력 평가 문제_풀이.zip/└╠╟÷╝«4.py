def place_value(number):
    return ("{:,}".format(number))

k = float(input("Enter the weight of a package (KG): "))
r = 0.0

if k <= 2:
    r = k*2000
elif 2 < k and k <= 6:
    r = k*3500
elif 6 < k and k <= 10:
    r = k*3800
else:
    r = k*4200

print("Your shipping charges for the package is "+place_value(int(r))+".")

