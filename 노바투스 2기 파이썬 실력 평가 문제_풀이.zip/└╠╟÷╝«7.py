k = input("Enter a number: ")

a = int(k)
b = int(k[::-1])
l = len(k)
h = int(l/2)
p = 1

for i in range(0,100):
    s = str(a)
    l = len(s)
    h = int(l/2)
    b = int(s[::-1])

    for j in range(0,h+1):
        if s[j] != s[l-1-j]:
            p = 0
            break
    
    if p == 1:
        print("Palindrome:",a)
        break;

    else:
        a = a+b
        p = 1

    if i == 99:
        print("No Palindrome!")



