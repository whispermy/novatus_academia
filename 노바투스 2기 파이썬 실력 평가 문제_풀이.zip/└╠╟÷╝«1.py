a = input("Enter the last name: ")
b = input("Enter the first name: ")

print("Your name is " + a + ", " + b + ".")

