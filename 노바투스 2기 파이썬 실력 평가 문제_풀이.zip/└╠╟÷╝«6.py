k = int(input("Enter the # of loops: "))
st = ''

for i in range(2,k+2):
    st = '#'
    for j in range(2,i):
        if i == k+1:
            st += '#'    
        else:
            st += ' '
    st += '#'
    print(st)

