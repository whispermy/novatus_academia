y = int(input("Enter a year: "))

if y%4 == 0:
    if y%100 == 0:
        if y%400 == 0:
            print("Leap year")
        else:
            print("Common year")
    else:
        print("Leap year")
else:
    print("Common year")

    