a = int(input("Enter the first test score: "))
b = int(input("Enter the second test score: "))
c = int(input("Enter the third test score: "))

print("The average score is ", (a+b+c)/3)
